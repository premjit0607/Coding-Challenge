package edu.jc.papers;

import java.util.Arrays;

public class Swap {

	public static void main(String[] args) {
		int[] a = {1, 7, 5, 3, 4, 6, 8};
		int swapCount = minimumSwaps(a);
		System.out.println(swapCount);
	}


	static int minimumSwaps(int[] arr) {
		for( int i = 0; i < arr.length; i++ ) {
			int cur = arr[i];
			if( i < arr.length - 1 &&  cur > arr[i+1] ) {
				arr[i] = arr[i+1];
				arr[i+1] = cur;
			}
		}
		System.out.println(Arrays.toString(arr));
		return 0;
	}

}
