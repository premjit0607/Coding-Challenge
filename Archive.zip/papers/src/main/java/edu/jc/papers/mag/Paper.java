package edu.jc.papers.mag;

import java.time.DayOfWeek;
import java.util.Map;

public class Paper {
	
	private String name;
	
	private Map<DayOfWeek, Double> priceDay;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Map<DayOfWeek, Double> getPriceDay() {
		return priceDay;
	}
	public void setPriceDay(Map<DayOfWeek, Double> priceDay) {
		this.priceDay = priceDay;
	}
	
}
