package edu.jc.papers.mag;

import java.time.DayOfWeek;
import java.util.HashMap;
import java.util.Map;

public class HT extends Paper{
	
	@Override
	public Map<DayOfWeek, Double> getPriceDay() {
		@SuppressWarnings("serial")
		Map<DayOfWeek, Double> toiPrice = new HashMap<DayOfWeek, Double>() {{
			put(DayOfWeek.MONDAY, 3.0);
			put(DayOfWeek.TUESDAY, 3.0);
			put(DayOfWeek.WEDNESDAY, 3.0);
			put(DayOfWeek.THURSDAY, 3.0);
			put(DayOfWeek.FRIDAY, 3.0);
			put(DayOfWeek.SATURDAY, 5.0);
			put(DayOfWeek.SUNDAY, 6.0);
		}};
		return toiPrice;
	}
	
	
}
