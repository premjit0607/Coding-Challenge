package edu.jc.papers;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.Arrays;
import java.util.Map;
import java.util.Map.Entry;

import edu.jc.papers.mag.Paper;
import edu.jc.papers.mag.PaperFactory;

public class ExpenseReport {
	public static void main(String[] args) {
		
		String[] subs = args[0].split(",");
		
		System.out.println(Arrays.toString(subs));
		
		double totalPrice = 0;
		
		for( String sub : subs ) {
			Paper p = PaperFactory.getPaper( sub.toUpperCase() );
			if( null != p ) {
				double expenseForTheSub = calculateExpenses( p );
				totalPrice = totalPrice + expenseForTheSub;
			}
		}
		
		System.out.println("total price "+ totalPrice);
		
	}

	private static double calculateExpenses(Paper p) {
		double totalPrice = 0.0;
		Map<DayOfWeek, Double> priceMap = p.getPriceDay();
		
		for ( Entry<DayOfWeek, Double> entry : priceMap.entrySet() ) {
			int noOfDays = countDayOccurenceInMonth(entry.getKey());
			double priceForTheDay = noOfDays * entry.getValue();
			totalPrice = totalPrice + priceForTheDay;
		}
		return totalPrice;
	}

	public static int countDayOccurenceInMonth(DayOfWeek dow) {
		YearMonth month = YearMonth.now();
		LocalDate start = month.atDay(1).with(TemporalAdjusters.nextOrSame(dow));
		return (int) ChronoUnit.WEEKS.between(start, month.atEndOfMonth()) + 1;
	}
	
	
	public static double getPriceForMonth( DayOfWeek dow ) {
		return 0;
	}

}
