package edu.jc.papers.mag;

import java.time.DayOfWeek;
import java.util.HashMap;
import java.util.Map;

public class ET extends Paper{
	
	@Override
	public Map<DayOfWeek, Double> getPriceDay() {
		@SuppressWarnings("serial")
		Map<DayOfWeek, Double> toiPrice = new HashMap<DayOfWeek, Double>() {{
			put(DayOfWeek.MONDAY, 2.0);
			put(DayOfWeek.TUESDAY, 2.0);
			put(DayOfWeek.WEDNESDAY, 2.0);
			put(DayOfWeek.THURSDAY, 2.0);
			put(DayOfWeek.FRIDAY, 2.0);
			put(DayOfWeek.SATURDAY, 2.0);
			put(DayOfWeek.SUNDAY, 10.0);
		}};
		return toiPrice;
	}
	
	
}
