package edu.jc.papers;

import java.io.IOException;
import java.util.Arrays;

/**
 * Hello world!
 *
 */
public class App 
{
	static int[] rotLeft(int[] a, int d) {
        int l = a.length;
        int[] ret = new int[l];
        for( int i = 0; i < l-d; i++ ){
            ret[i] = a[i+d];
        }
        return ret;
    }


    public static void main(String[] args) throws IOException {
        int[] a = {1, 2 ,3, 4, 6, 8, 7};
        int shiftBy = 3;
        
        System.out.println(Arrays.toString( a ));
        
        int[] temp = new int[ a.length ];
        
        for (int i = 0; i < (a.length - shiftBy); i++) {
			temp[i] = a[ i +shiftBy ];
		}
        
        int shifted = a.length - shiftBy;
        
        for( int i = 0; i < shiftBy; i++ ) {
        	temp[shifted+i] = a[i];
        }
        
        System.out.println( Arrays.toString( temp ) );
    }
}
