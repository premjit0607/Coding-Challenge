package edu.jc.papers.mag;

public class PaperFactory {
	public static Paper getPaper(String paperType) {
		Paper paper = null; 
		switch (paperType) {
		
		case "TOI":
			paper = new TOI();
			break;
			
		case "HINDU":
			paper = new Hindu();
			break;
			
		case "ET":
			paper = new ET();
			break;
			
		case "BM":
			paper = new BM();
			break;
			
		case "HT":
			paper = new HT();
			break;

		default:
			break;
		}
		return paper;
	}
}
