package edu.jc.papers.mag;

import java.time.DayOfWeek;
import java.util.HashMap;
import java.util.Map;

public class Hindu extends Paper{
	
	@Override
	public Map<DayOfWeek, Double> getPriceDay() {
		@SuppressWarnings("serial")
		Map<DayOfWeek, Double> hindu = new HashMap<DayOfWeek, Double>() {{
			put(DayOfWeek.MONDAY, 2.5);
			put(DayOfWeek.TUESDAY, 2.5);
			put(DayOfWeek.WEDNESDAY, 2.5);
			put(DayOfWeek.THURSDAY, 2.5);
			put(DayOfWeek.FRIDAY, 2.5);
			put(DayOfWeek.SATURDAY, 4.0);
			put(DayOfWeek.SUNDAY, 4.0);
		}};
		return hindu;
	}
	
	
}
