package edu.jc.papers.mag;

import java.time.DayOfWeek;
import java.util.HashMap;
import java.util.Map;

public class BM extends Paper{
	
	@Override
	public Map<DayOfWeek, Double> getPriceDay() {
		@SuppressWarnings("serial")
		Map<DayOfWeek, Double> toiPrice = new HashMap<DayOfWeek, Double>() {{
			put(DayOfWeek.MONDAY, 1.5);
			put(DayOfWeek.TUESDAY, 1.5);
			put(DayOfWeek.WEDNESDAY, 1.5);
			put(DayOfWeek.THURSDAY, 1.5);
			put(DayOfWeek.FRIDAY, 1.5);
			put(DayOfWeek.SATURDAY, 1.5);
			put(DayOfWeek.SUNDAY, 1.5);
		}};
		return toiPrice;
	}
	
	
}
